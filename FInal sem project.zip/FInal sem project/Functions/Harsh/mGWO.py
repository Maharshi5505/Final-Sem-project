# -*- coding: utf-8 -*-
"""
Created on Mon May 16 00:27:50 2016

@author: Hossam Faris
"""

import random
import numpy

from solution import solution
import time

import math    
import copy    
import sys     
import numpy
import csv
import time

num_particles = 50
max_iter = 100
 

ExportToFile="experiment"+time.strftime("%Y-%m-%d-%H-%M-%S")+".csv"

# CSV Header for for the cinvergence 
CnvgHeader=[]

for l in range(0,max_iter):
	CnvgHeader.append("Iter"+str(l+1))

flag = False

#-------fitness functions---------
 
# rastrigin function
def fitness_rastrigin(x):
  sum = 0
  j = 0
  length = len(x)
  for i in range(length):
      sum = sum + (x[i]**2 - 10*math.cos(2*math.pi*x[i])+10)
  return sum
 
#sphere function
def fitness_sphere(position):
    fitness_value = 0.0
    for i in range(len(position)):
        xi = position[i]
        fitness_value += (xi*xi)
    return fitness_value
#-------------------------

def fitness_sumSqueres(x):
    sum = 0
    j = 0
    for i in range(len(x)):
        j = j+1
        Ai = x[i]
        sum = sum + j*(Ai*Ai)
    return sum
def ackley(x):
    sum1=0
    sum2=0
    a=20
    b=0.2
    c=2*math.pi
    length= len(x)
    for i in range(length):
        sum1 = sum1 + (x[i]**2)
        sum2 = sum2 + math.cos(c*x[i])
    y = -a*math.exp(-b*math.sqrt(1/length*sum1)) - math.exp(1/length*sum2)+a+math.exp(1)
    return y

def griewank(x):
    fr = 4000
    s=0
    p=1
    n=len(x)
    j=0
    for i in range(n):
        s = s + x[i]**2
    for i in range(n):
        if(i==0):
            p = p*math.cos(x[i]/math.sqrt(i+1))
        else :
            p = p*math.cos(x[i]/math.sqrt(i))
    y = (s/fr)-p+1
    return y

def invertedCosine(x):
    n=len(x)
    s=0
    p=0
    for i in range(n):
        s = s + x[i]**2
    for i in range(n):
        p = p+math.cos(5*math.pi*x[i])
    y = (0.1*n) - ((0.1*p) - s)
    return y

def alpine(x):
    n = len(x)
    y=0
    for i in range(n):
        p = (x[i] * math.sin(x[i])) + (0.1 * x[i])
        y = y + abs(p)
    return y

def levy(x):
    n=len(x)
    p = (math.sin(3*math.pi*x[1]))**2
    q = (x[-1] -1)*(1+(math.sin(3*math.pi*x[-1])*math.sin(3*math.pi*x[-1])))
    s=0
    for i in range(n-1):
        s = s + ((x[i] -1)**2)*(1 + (1+(math.sin(3*3.1415*x[i+1])**2)))
    y = s+p+q
    return y

##Salomon

def salomon(x):
    s=0
    n=len(x)
    for i in range(n):
        s = s + x[i]**2
    p = math.cos(2 * math.pi * math.sqrt(s))
    q = 0.1 * math.sqrt(s)
    y = 1 - p + q
    return y

def elliptic(x):
    n = len(x)
    s=0
    for i in range(n):
        s = s + ((10**6)**((i-1)/n-1)) * (x[i]**2)
    return s

# wolf class
class wolf:
  def __init__(self, fitness, dim, minx, maxx, seed):
    self.rnd = random.Random(seed)
    self.position = [0.0 for i in range(dim)]
 
    for i in range(dim):
      self.position[i] = ((maxx - minx) * self.rnd.random() + minx)
 
    self.fitness = fitness(self.position) # curr fitness
    
    print(self.position)
 

Convergence_curve=numpy.zeros(max_iter) 

    


#def GWO(objf,lb,ub,dim,SearchAgents_no,Max_iter):
def gwo(objf,Max_iter,SearchAgents_no,dim,lb,ub):
    print("GWO")
    print("Dimentions = " + str(dim))


   
    
    #Max_iter=1000
    #lb=-100
    #ub=100
    #dim=30  
    #SearchAgents_no=5
    
    # initialize alpha, beta, and delta_pos
    Alpha_pos=numpy.zeros(dim)
    Alpha_score=float("inf")
    # print("Alpha_score = " + str(Alpha_score))
    
    
    Beta_pos=numpy.zeros(dim)
    Beta_score=float("inf")
    
    Delta_pos=numpy.zeros(dim)
    Delta_score=float("inf")
    
    #Initialize the positions of search agents
    Positions=numpy.random.uniform(0,1,(SearchAgents_no,dim)) *(ub-lb)+lb
    # print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    # print(len(Positions))
    
    s=solution()
    # print(type(s))
     # Loop counter
    print("GWO is optimizing  \""+objf.__name__+"\"")    
    
    timerStart=time.time() 
    s.startTime=time.strftime("%Y-%m-%d-%H-%M-%S")
    # Main loop
    for l in range(0,Max_iter):
        for i in range(0,SearchAgents_no):
            
            # Return back the search agents that go beyond the boundaries of the search space
            # print(len(Positions))
            Positions[i,:]=numpy.clip(Positions[i,:], lb, ub)
            # print(len(Positions))
            # print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
            # print(Positions[-1])
            # print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")

            # Calculate objective function for each search agent
            fitness=objf(Positions[i,:])
            
            # Update Alpha, Beta, and Delta
        
            if fitness<Alpha_score :
                Alpha_score=fitness; # Update alpha
                Alpha_pos=Positions[i,:].copy()
            
            
            if (fitness>Alpha_score and fitness<Beta_score ):
                Beta_score=fitness  # Update beta
                Beta_pos=Positions[i,:].copy()
            
            
            if (fitness>Alpha_score and fitness>Beta_score and fitness<Delta_score): 
                Delta_score=fitness # Update delta
                Delta_pos=Positions[i,:].copy()
            
        
        
        
        a=2-(l*l)*((2)/(Max_iter*Max_iter)); # a decreases linearly fron 2 to 0
        
        # Update the Position of search agents including omegas
        for i in range(0,SearchAgents_no):
            for j in range (0,dim):     
                           
                r1=random.random() # r1 is a random number in [0,1]
                r2=random.random() # r2 is a random number in [0,1]
                
                A1=2*a*r1-a; # Equation (3.3)
                C1=2*r2; # Equation (3.4)
                
                D_alpha=abs(C1*Alpha_pos[j]-Positions[i,j]); # Equation (3.5)-part 1
                X1=Alpha_pos[j]-A1*D_alpha; # Equation (3.6)-part 1
                           
                r1=random.random()
                r2=random.random()
                
                A2=2*a*r1-a; # Equation (3.3)
                C2=2*r2; # Equation (3.4)
                
                D_beta=abs(C2*Beta_pos[j]-Positions[i,j]); # Equation (3.5)-part 2
                X2=Beta_pos[j]-A2*D_beta; # Equation (3.6)-part 2       
                
                r1=random.random()
                r2=random.random() 
                
                A3=2*a*r1-a; # Equation (3.3)
                C3=2*r2; # Equation (3.4)
                
                D_delta=abs(C3*Delta_pos[j]-Positions[i,j]); # Equation (3.5)-part 3
                X3=Delta_pos[j]-A3*D_delta; # Equation (3.5)-part 3             
                
                Positions[i,j]=(X1+X2+X3)/3  # Equation (3.7)
                
            
        
        
        Convergence_curve[l]=Alpha_score

        if (l%1==0):
               print(['At iteration '+ str(l)+ ' the best fitness is '+ str(Alpha_score)])
    

    print(Positions[-1])
    timerEnd=time.time()  
    s.endTime=time.strftime("%Y-%m-%d-%H-%M-%S")
    s.executionTime=timerEnd-timerStart
    s.convergence=Convergence_curve
    s.optimizer="mGWO"
    s.objfname=objf.__name__
    s.bestIndividual=Alpha_pos
    
    
    
    return Alpha_pos
    
 
# Driver code for rastrigin function
 
print("\nBegin grey wolf optimization on rastrigin function\n")
dim = 3
fitness = fitness_rastrigin

print("Goal is to minimize Rastrigin's function in " + str(dim) + " variables")
print("Function has known min = 0.0 at (", end="")
for i in range(dim-1):
  print("0, ", end="")
print("0)")

print("Setting num_particles = " + str(num_particles))
print("Setting max_iter    = " + str(max_iter))
print("\nStarting mGWO algorithm\n")
 
 
 
best_position = gwo(fitness, max_iter, num_particles, dim, -5.0, 5.0)
 
print("\nGWO completed\n")
print("\nBest solution found:")
print(["%.6f"%best_position[k] for k in range(dim)])
# print(best_position)
err = fitness(best_position)
print("fitness of best solution = %.6f" % err)

with open(ExportToFile, 'a',newline='\n') as out:
    writer = csv.writer(out,delimiter=',')
    if (flag==False): # just one time to write the header of the CSV file
        header= numpy.concatenate([["Optimizer","Benchmark Function","Best Solution"],CnvgHeader])
        writer.writerow(header)
    a=numpy.concatenate([["mGWO","Rstrigin",err],Convergence_curve])
    writer.writerow(a)
    out.close()
flag=True

print("\nEnd mGWO for rastrigin\n")
print("==========================================================================")
 
 
# print()
# print()
 
 
# Driver code for Sphere function
print("\nBegin grey wolf optimization on sphere function\n")
dim = 3
fitness = fitness_sphere
print("Goal is to minimize sphere function in " + str(dim) + " variables")
print("Function has known min = 0.0 at (", end="")
for i in range(dim-1):
  print("0, ", end="")
print("0)")
 
print("Setting num_particles = " + str(num_particles))
print("Setting max_iter    = " + str(max_iter))
print("\nStarting mGWO algorithm\n")
 
 
 
best_position = gwo(fitness, max_iter, num_particles, dim, -5.0, 5.0)
 
print("\nmGWO completed\n")
print("\nBest solution found:")
print(["%.6f"%best_position[k] for k in range(dim)])
err = fitness(best_position)
print("fitness of best solution = %.6f" % err)

with open(ExportToFile, 'a',newline='\n') as out:
    writer = csv.writer(out,delimiter=',')
    
    a=numpy.concatenate([["mGWO","Sphere",err],Convergence_curve])
    writer.writerow(a)
    out.close()
flag=True
 
print("\nEnd mGWO for sphere\n")

print("==========================================================================")
print("\nBegin grey wolf optimization on invertedCosine function\n")
fitness = invertedCosine
print("Goal is to minimize invertedCosine function in " + str(dim) + " variables")
print("Function has known min = 0.0 at (", end="")
for i in range(dim-1):
  print("0, ", end="")
print("0)")
 
print("Setting num_particles = " + str(num_particles))
print("Setting max_iter    = " + str(max_iter))
print("\nStarting GWO algorithm\n")
best_position = gwo(fitness, max_iter, num_particles, dim, -5.0, 5.0)
 
print("\nGWO completed\n")
print("\nBest solution found:")
print(["%.6f"%best_position[k] for k in range(dim)])
err = fitness(best_position)
print("fitness of best solution = %.6f" % err)

with open(ExportToFile, 'a',newline='\n') as out:
    writer = csv.writer(out,delimiter=',')
    
    a=numpy.concatenate([["mGWO","Inverted Cosine",err],Convergence_curve])
    writer.writerow(a)
    out.close()
flag=True

print("\nEnd GWO for invertedCosine\n")

print("==========================================================================")
print("\nBegin grey wolf optimization on elliptic function\n")

fitness = elliptic

print("Goal is to minimize elliptic's function in " + str(dim) + " variables")
print("Function has known min = 0.0 at (", end="")
for i in range(dim-1):
  print("0, ", end="")
print("0)")
 

print("Setting num_particles = " + str(num_particles))
print("Setting max_iter    = " + str(max_iter))
print("\nStarting GWO algorithm\n")
 
 
 
best_position = gwo(fitness, max_iter, num_particles, dim, -5.0, 5.0)
 
print("\nGWO completed\n")
print("\nBest solution found:")
print(["%.6f"%best_position[k] for k in range(dim)])
err = fitness(best_position)
print("fitness of best solution = %.6f" % err)

with open(ExportToFile, 'a',newline='\n') as out:
    writer = csv.writer(out,delimiter=',')
    
    a=numpy.concatenate([["mGWO","Elliptic",err],Convergence_curve])
    writer.writerow(a)
    out.close()
flag=True

print("\nEnd GWO for elliptic\n")
print("==========================================================================")

print("\nBegin grey wolf optimization on salomon function\n")
fitness = salomon

print("Goal is to minimize salomon's function in " + str(dim) + " variables")
print("Function has known min = 0.0 at (", end="")
for i in range(dim-1):
  print("0, ", end="")
print("0)")
 
print("Setting num_particles = " + str(num_particles))
print("Setting max_iter    = " + str(max_iter))
print("\nStarting GWO algorithm\n")
 
 
 
best_position = gwo(fitness, max_iter, num_particles, dim, -5.0, 5.0)
 
print("\nGWO completed\n")
print("\nBest solution found:")
print(["%.6f"%best_position[k] for k in range(dim)])
err = fitness(best_position)
print("fitness of best solution = %.6f" % err)

with open(ExportToFile, 'a',newline='\n') as out:
    writer = csv.writer(out,delimiter=',')
    
    a=numpy.concatenate([["mGWO","Salomon",err],Convergence_curve])
    writer.writerow(a)
    out.close()
flag=True

print("\nEnd GWO for salomon\n")
print("==========================================================================")
print("\nBegin grey wolf optimization on levy function\n")
fitness = levy


print("Goal is to minimize levy's function in " + str(dim) + " variables")
print("Function has known min = 0.0 at (", end="")
for i in range(dim-1):
  print("0, ", end="")
print("0)")
 
print("Setting num_particles = " + str(num_particles))
print("Setting max_iter    = " + str(max_iter))
print("\nStarting GWO algorithm\n")
 
 
 
best_position = gwo(fitness, max_iter, num_particles, dim, -5.0, 5.0)
 
print("\nGWO completed\n")
print("\nBest solution found:")
print(["%.6f"%best_position[k] for k in range(dim)])
err = fitness(best_position)
print("fitness of best solution = %.6f" % err)

with open(ExportToFile, 'a',newline='\n') as out:
    writer = csv.writer(out,delimiter=',')
    
    a=numpy.concatenate([["mGWO","Levy",err],Convergence_curve])
    writer.writerow(a)
    out.close()
flag=True

print("\nEnd GWO for levy\n")

print("==========================================================================")
print("\nBegin grey wolf optimization on alpine function\n")
fitness = alpine

print("Goal is to minimize alpine's function in " + str(dim) + " variables")
print("Function has known min = 0.0 at (", end="")
for i in range(dim-1):
  print("0, ", end="")
print("0)")
 
print("Setting num_particles = " + str(num_particles))
print("Setting max_iter    = " + str(max_iter))
print("\nStarting GWO algorithm\n")
 
 
 
best_position = gwo(fitness, max_iter, num_particles, dim, -5.0, 5.0)
 
print("\nGWO completed\n")
print("\nBest solution found:")
print(["%.6f"%best_position[k] for k in range(dim)])
err = fitness(best_position)
print("fitness of best solution = %.6f" % err)

with open(ExportToFile, 'a',newline='\n') as out:
    writer = csv.writer(out,delimiter=',')
    
    a=numpy.concatenate([["mGWO","Alpine",err],Convergence_curve])
    writer.writerow(a)
    out.close()
flag=True

print("\nEnd GWO for alpine\n")
print("==========================================================================")
print("\nBegin grey wolf optimization on sumSqueres function\n")
fitness = fitness_sumSqueres
# fitness = ackley
# fitness = griewank
print("Goal is to minimize sumSqueres function in " + str(dim) + " variables")
print("Function has known min = 0.0 at (", end="")
for i in range(dim-1):
  print("0, ", end="")
print("0)")
 
print("Setting num_particles = " + str(num_particles))
print("Setting max_iter    = " + str(max_iter))
print("\nStarting GWO algorithm\n")
 
 
 
best_position = gwo(fitness, max_iter, num_particles, dim, -5.0, 5.0)
 
print("\nGWO completed\n")
print("\nBest solution found:")
print(["%.6f"%best_position[k] for k in range(dim)])
err = fitness(best_position)
print("fitness of best solution = %.6f" % err)

with open(ExportToFile, 'a',newline='\n') as out:
    writer = csv.writer(out,delimiter=',')
    
    a=numpy.concatenate([["mGWO","Sum Squeres",err],Convergence_curve])
    writer.writerow(a)
    out.close()
flag=True

print("\nEnd GWO for sumSqueres\n")
print("==========================================================================")

print("\nBegin grey wolf optimization on ackley function\n")
fitness = ackley

print("Goal is to minimize ackley function in " + str(dim) + " variables")
print("Function has known min = 0.0 at (", end="")
for i in range(dim-1):
  print("0, ", end="")
print("0)")
 
print("Setting num_particles = " + str(num_particles))
print("Setting max_iter    = " + str(max_iter))
print("\nStarting GWO algorithm\n")
 
 
 
best_position = gwo(fitness, max_iter, num_particles, dim, -5.0, 5.0)
 
print("\nGWO completed\n")
print("\nBest solution found:")
print(["%.6f"%best_position[k] for k in range(dim)])
err = fitness(best_position)
print("fitness of best solution = %.6f" % err)

with open(ExportToFile, 'a',newline='\n') as out:
    writer = csv.writer(out,delimiter=',')
    
    a=numpy.concatenate([["mGWO","Ackley",err],Convergence_curve])
    writer.writerow(a)
    out.close()
flag=True

print("\nEnd GWO for ackley\n")
print("==========================================================================")
print("\nBegin grey wolf optimization on griewank function\n")
fitness = griewank
print("Goal is to minimize griewank function in " + str(dim) + " variables")
print("Function has known min = 0.0 at (", end="")
for i in range(dim-1):
  print("0, ", end="")
print("0)")
 
print("Setting num_particles = " + str(num_particles))
print("Setting max_iter    = " + str(max_iter))
print("\nStarting GWO algorithm\n")
 
 
 
best_position = gwo(fitness, max_iter, num_particles, dim, -5.0, 5.0)
 
print("\nGWO completed\n")
print("\nBest solution found:")
print(["%.6f"%best_position[k] for k in range(dim)])
err = fitness(best_position)
print("fitness of best solution = %.6f" % err)

with open(ExportToFile, 'a',newline='\n') as out:
    writer = csv.writer(out,delimiter=',')
    
    a=numpy.concatenate([["mGWO","Griewank",err],Convergence_curve])
    writer.writerow(a)
    out.close()
flag=True

print("\nEnd GWO for griewank\n")
print("==========================================================================")

