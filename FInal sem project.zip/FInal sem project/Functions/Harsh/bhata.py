# bhattacharyya test
import numpy
import math
import statistics
from numpy import log as ln

h1 = [10, 20, 15, 10, 5];
h2 = [10, 20, 15, 10, 5];
# h2 = [50, 60, 80, 100, 70];
# h1 = [0.1,0.2,0.4,0.3,0.7]
# # h2 = [0.1,0.2,0.4,0.3,0.7]
# h2 = [0.9,0.8,0.9,0.1,0.2]
# h1 = [1,1,1,1,1]
# h2 = [1,1,1,1,1]

# h1 = [0,1,1,1,0]
# h2 = [1,0,0,1,1]

def mean( h ):
    mean = 0.0;
    for i in h:
        mean += i;
    mean/= len(h);
    return mean;

def bhatta ( h1,  h2):
    # mean of h1
    
    # calculate score
    score = 0;
    for i in range(len(h1)):
        score += math.sqrt( h1[i] * h2[i] );
    # print h1_,h2_,score;
    print( "Bhatacharya coefficient = ",score)
    ans = -float(ln(score))
    return ans;

score = bhatta(h1,h2);
print("distance = ",score)